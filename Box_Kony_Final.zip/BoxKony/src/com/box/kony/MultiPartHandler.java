package com.box.kony;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.FileCleanerCleanup;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileCleaningTracker;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import com.konylabs.middleware.controller.DataControllerRequest;

public class MultiPartHandler {
	private static Logger log = Logger.getLogger(MultiPartHandler.class); 
	private static DiskFileItemFactory FILE_ITEM_FACTORY;
	private static String FILE_UPLOAD_DIR = System.getProperty("java.io.tmpdir"); 
	public MultiPartHandler(){}
	public List<FormItem> handleMultipart(DataControllerRequest dataControllerRequest) throws Exception {
		// Check that we have a file upload request
	    if (!isMultipartRequest(dataControllerRequest)) {
	        return null;
	    }
	    HttpServletRequest request = (HttpServletRequest) dataControllerRequest.getOriginalRequest();
	    if (FILE_ITEM_FACTORY == null) {
			createItemFactory(request);
		}
	    return parseMultipartBody(request);
	}
	public static boolean isMultipartRequest(DataControllerRequest dataControllerRequest) {
	    if (dataControllerRequest != null || dataControllerRequest.getOriginalRequest() != null) {
	        HttpServletRequest request = (HttpServletRequest) dataControllerRequest.getOriginalRequest();
	        // Check that we have a file upload request
	        if (ServletFileUpload.isMultipartContent(request)) {
	            return true;
	        }
        }
	    return false;
	}
	private static synchronized void createItemFactory(HttpServletRequest request) {
		if (FILE_ITEM_FACTORY == null) {
			// Create a factory for disk-based file items
			DiskFileItemFactory factory = new DiskFileItemFactory();

			// Set factory constraints
			factory.setSizeThreshold(DiskFileItemFactory.DEFAULT_SIZE_THRESHOLD); 
			factory.setRepository(new File(FILE_UPLOAD_DIR));

			// Set overall request size constraint
			// upload.setSizeMax(yourMaxRequestSize); 
			
			// starting file cleaner thread for cleaning temp files created by the library in this process. 
			// We are obtaining the instance of FileCleaningTracker through FileCleanerCleanup listener 
			// associated by middleware in services web.xml. Closing is cleaner thread is handled by that listener.
			FileCleaningTracker fileCleaningTracker = FileCleanerCleanup.getFileCleaningTracker(request.getServletContext());
			factory.setFileCleaningTracker(fileCleaningTracker);
			FILE_ITEM_FACTORY = factory;
		}
	}
	/**
	 * Methods that parses the multipart body 
	 * 
	 * @param request
	 * @return
	 */
	private static List<FormItem> parseMultipartBody(HttpServletRequest request) throws Exception{
		try {
			List<FormItem> formItems = new ArrayList<>();
			ServletFileUpload upload = new ServletFileUpload(FILE_ITEM_FACTORY);
			List<FileItem> fileItems = upload.parseRequest(request);
			System.out.println("##"+fileItems);
			String fileName = null;
			String fileBaseName = null;
			String fileExtension = null;
			String fileContentType = null;
			long fileSize;
			File file = null;
			for (FileItem item : fileItems) {
				if (item.isFormField()) { // if form parameter
					formItems.add(new FormItem(false, item.getFieldName(), item.getString(), null, null, null, 0, null));
				} else { // if file
					fileName = FilenameUtils.getName(item.getName());
					fileBaseName = FilenameUtils.getBaseName(item.getName());
					fileExtension = FilenameUtils.getExtension(item.getName());
					fileContentType = item.getContentType();
					fileSize = item.getSize();
					file = new File(FILE_UPLOAD_DIR, fileBaseName+"."+fileExtension);// + "_" + (new Date()).getTime() + "." + fileExtension);
					item.write(file); // all underlying resources will be closed inside this call
					formItems.add(new FormItem(true, item.getFieldName(), null, fileName, fileExtension, fileContentType, fileSize, file));
				}
			}
			return formItems;
		} catch (Exception e) {
			log.error("Failed while parsing multipart request"+ e.getMessage());
			throw e;
		}
		
	}
}
