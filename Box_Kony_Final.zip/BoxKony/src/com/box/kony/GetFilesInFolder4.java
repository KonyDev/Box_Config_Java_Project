package com.box.kony;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.jose4j.json.internal.json_simple.JSONArray;
import org.jose4j.json.internal.json_simple.JSONObject;

import com.box.sdk.BoxConfig;
import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxFile;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxItem;
import com.box.sdk.BoxSharedLink;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;
import com.box.sdk.JWTEncryptionPreferences;
import com.konylabs.middleware.common.JavaService2;
import com.konylabs.middleware.controller.DataControllerRequest;
import com.konylabs.middleware.controller.DataControllerResponse;
import com.konylabs.middleware.dataobject.Param;
import com.konylabs.middleware.dataobject.Result;

public class GetFilesInFolder4 implements JavaService2 {
	private static final int MAX_CACHE_ENTRIES = 100;
	private static Logger log = Logger.getLogger(Logger.class);

	

	public JSONObject getFiles(String appUserID, String folderID) {
		log.debug("#### Entering the getFiles method of GetFilesInFolder service ####");
		log.debug("#### appUserID :"+appUserID);
		log.debug("#### folderID :"+folderID);
		JSONArray fileList = new JSONArray();
		JSONObject result=new JSONObject(),jObj = null;
		BoxFile file;
		BoxSharedLink sharedLink;
		BoxFolder.Info childFolder = null;
		try {
			log.debug("#### Creating the box config ####");
			BoxConfig boxConfig = BoxUtil.getBoxConfig();
			JWTEncryptionPreferences encryptionPref = boxConfig.getJWTEncryptionPreferences();
			IAccessTokenCache accessTokenCache = new InMemoryLRUAccessTokenCache(MAX_CACHE_ENTRIES);
			BoxDeveloperEditionAPIConnection userApiConnection = BoxDeveloperEditionAPIConnection.getAppUserConnection(
					appUserID, boxConfig.getClientId(), boxConfig.getClientSecret(), encryptionPref, accessTokenCache);
			BoxFolder boxFolder = new BoxFolder(userApiConnection, folderID);
			BoxSharedLink.Permissions permissions = new BoxSharedLink.Permissions();
			permissions.setCanDownload(true);
			permissions.setCanPreview(true);
			/*
			 * BoxItem.Info folderInfo = boxFolder.getInfo();
			 * System.out.println(folderInfo.getName()+":"+folderInfo.getID());
			 */
			log.debug("#### Listingiting items in the  config ####");
			for (BoxItem.Info itemInfo : boxFolder) {
				if (itemInfo instanceof BoxFile.Info) {
					BoxFile.Info fileInfo = (BoxFile.Info) itemInfo;
					System.out.println(fileInfo.getName() + ":" + fileInfo.getID());
					file = new BoxFile(userApiConnection, fileInfo.getID());
					sharedLink = file.createSharedLink(BoxSharedLink.Access.OPEN, null, permissions);

					System.out.println("shared link: " + sharedLink.getURL());
					System.out.println("download url: " + sharedLink.getDownloadURL());
					
					log.debug("file_name: "+fileInfo.getName());
					log.debug("file_ID: "+ fileInfo.getID());
					log.debug("shared_url: "+ sharedLink.getURL());
					log.debug("download_url: "+ sharedLink.getDownloadURL());
					log.debug("type: "+ "file");
					
					jObj = new JSONObject();
					jObj.put("file_name", fileInfo.getName());
					jObj.put("file_ID", fileInfo.getID());
					jObj.put("shared_url", sharedLink.getURL());
					jObj.put("download_url", sharedLink.getDownloadURL());
					jObj.put("type", "file");
					fileList.add(jObj);
					// Do something with the file.
				} else if (itemInfo instanceof BoxFolder.Info) {
					childFolder = (BoxFolder.Info) itemInfo;
					System.out.println(childFolder.getName() + ":" + childFolder.getID());
					jObj = new JSONObject();
					jObj.put("file_name", childFolder.getName());
					jObj.put("file_ID", childFolder.getID());
					jObj.put("shared_url", null);
					jObj.put("download_url", null);
					jObj.put("type", "folder");
					fileList.add(jObj);
					
					log.debug("folder_name: "+childFolder.getName());
					log.debug("folder_ID: "+ childFolder.getID());
					log.debug("shared_url: "+ null);
					log.debug("download_url: "+ null);
					log.debug("type: "+ "folder");
					// Do something with the folder.
				}
			}
			result.put("status", "200");
			result.put("message","OK");
			result.put("result", fileList);
		} catch (Exception e) {
			// TODO: handle exception
			result.put("status", "400");
			result.put("message",e.getMessage());
			result.put("result", fileList);
			log.debug("Exception occured in getFIles method: "+e.getMessage());
		}
		log.debug("Final result to return: "+result.toString());
		log.debug("#### Exiting the getFiles method of GetFilesInFolder service ####");
		return result;
	}

	@Override
	public Object invoke(String arg0, Object[] arg1, DataControllerRequest arg2, DataControllerResponse arg3)
			throws Exception {
		// TODO Auto-generated method stub
		log.debug("#### Entering the invoke method of GetFilesInFolder service ####");
		HashMap<String, Object> params = (HashMap) arg1[1];
		String appUserID = (String) params.get("appUserID");
		String folderID = (String) params.get("folderID");
		log.debug("#### appUserID :"+appUserID);
		log.debug("#### folderID :"+folderID);
		
		Result finalResult = new Result();
		Param finalParam = new Param();
		finalParam.setName("results");
		finalParam.setType("String");
		
		JSONObject result= getFiles(appUserID, folderID);
		finalParam.setValue(result.toJSONString());
		
		finalResult.setParam(finalParam);
		
		log.debug("#### Exiting the invoke method of GetFilesInFolder service ####");
		log.debug("Final result to return: "+finalResult.toString());
		return finalResult;
		
	}
}