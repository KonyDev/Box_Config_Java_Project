package com.box.kony;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;
import org.jose4j.json.internal.json_simple.JSONArray;
import org.jose4j.json.internal.json_simple.JSONObject;

import com.box.sdk.BoxConfig;
import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxFile;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxItem;
import com.box.sdk.BoxSharedLink;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;
import com.box.sdk.JWTEncryptionPreferences;
import com.konylabs.middleware.common.JavaService2;
import com.konylabs.middleware.controller.DataControllerRequest;
import com.konylabs.middleware.controller.DataControllerResponse;
import com.konylabs.middleware.dataobject.Param;
import com.konylabs.middleware.dataobject.Result;

public class UploadFilesInFolder implements JavaService2 {
	private static final int MAX_CACHE_ENTRIES = 100;
	Logger log = Logger.getLogger(Logger.class);
	BoxSharedLink.Permissions permissions = new BoxSharedLink.Permissions();
	/*
	 * public static void main(String[] args) { // TODO Auto-generated method
	 * stub
	 * 
	 * }
	 */
	@Override
	public Object invoke(String arg0, Object[] arg1, DataControllerRequest requestInstance, DataControllerResponse arg3)
			throws Exception {
		// TODO Auto-generated method stub
		log.debug("#### Entering the invoke method of UploadFilesInFolder service ####");
		log.debug("Start Time is " + new Date().getTime());
		log.debug("Service Invoked");
		Result finalResult = new Result();
		JSONObject result = new JSONObject();
		JSONObject processedRequest;
		permissions.setCanDownload(true);
		permissions.setCanPreview(true);
		JSONArray jsonArray=new JSONArray();
		try{
			processedRequest=processRequest(requestInstance);
			jsonArray=uploadFiles(processedRequest);
			finalResult.getParamList().add(new Param("message","upload success!", "String"));
		}catch (Exception e) {
			// TODO: handle exception
			log.debug("#### Exception occured in the invoke method of UploadFilesInFolder service: "+e.getMessage());
			System.out.println("#### Exception occured in the invoke method of UploadFilesInFolder service: "+e.getMessage());
			finalResult.getParamList().add(new Param("message",e.getMessage(), "String"));
		}
		log.debug("#### result to be sent of the  invoke method of UploadFilesInFolder service: "+result.toString());
		log.debug("#### Exiting the invoke method of UploadFilesInFolder service ####");
		Param finalParam = new Param();
		finalParam.setName("results");
		finalParam.setObjectValue(jsonArray);
		finalParam.setType("collection");
		finalResult.setParam(finalParam);
		return finalResult;
	}
	public JSONObject processRequest(DataControllerRequest requestInstance) throws Exception{
		log.debug("#### Entering the processRequest method of UploadFilesInFolder service ####");
		List<FormItem> formItems = new MultiPartHandler().handleMultipart(requestInstance);
		List<File> fileList=new ArrayList<File>();
		File file;
		String paramName;
		String appUserID = null;
		String folderID=null;
		JSONObject jsonObject=new JSONObject();
		if (MultiPartHandler.isMultipartRequest(requestInstance)) {
			if (formItems != null) {
				log.debug("#### Form items are not null");
				for (FormItem currFormItem : formItems) {
					//requestInstance.addRequestParam_(currFormItem.getParamName(), currFormItem.getParamValue());
					if (currFormItem.isFile()) {
						log.debug("File Detected is" + currFormItem.getFileName());
							file = currFormItem.getFile();
							fileList.add(file);
					} else {
						paramName = currFormItem.getParamName();
						if (paramName.equals("appUserID")) {
							appUserID = currFormItem.getParamValue();
						} else if (paramName.equals("folderID")) {
							folderID = currFormItem.getParamValue();
						}
					}
				}
			}
		}else{
			log.debug("#### Not a multipart request ####");
			System.out.println("#### Not a multipart request ####");
		}
		jsonObject.put("appUserID", appUserID);
		jsonObject.put("folderID", folderID);
		jsonObject.put("fileList", fileList);
		log.debug("#### processedRequest: "+jsonObject.toString());
		log.debug("#### Exiting the processRequest method of UploadFilesInFolder service ####");
		return jsonObject;
	}
	public JSONArray uploadFiles(JSONObject files)throws Exception{
		List<File> fileList=new ArrayList<File>();
		String appUserID = null;
		String folderID=null;
		String fileName;
		String fileId = null;
		BoxFile boxFile;
		Map<String,String> fileMap=new HashMap<String,String>();
		appUserID=(String) files.get("appUserID");
		folderID=(String) files.get("folderID");
		fileList=(List<File>) files.get("fileList");
		BoxFile.Info fileInfo=null;
		BoxSharedLink sharedLink;
		JSONArray jsonArray=new JSONArray();
		JSONObject jsonObject;//=new JSONObject();
		
		InputStream fileStreamObject;
		BoxConfig boxConfig = BoxUtil.getBoxConfig();
		
		
		JWTEncryptionPreferences encryptionPref = boxConfig.getJWTEncryptionPreferences();
		IAccessTokenCache accessTokenCache = new InMemoryLRUAccessTokenCache(MAX_CACHE_ENTRIES);
		BoxDeveloperEditionAPIConnection userApiConnection = BoxDeveloperEditionAPIConnection.getAppUserConnection(
				appUserID, boxConfig.getClientId(), boxConfig.getClientSecret(), encryptionPref, accessTokenCache);
		BoxFolder childFolder = new BoxFolder(userApiConnection, folderID);
		
		fileMap=getExistingFilesInFolder(childFolder);
		
		log.debug("#### uploading files ####");
		System.out.println("#### uploading files ####");
		for(File file:fileList){
			fileName=file.getName();
			jsonObject=new JSONObject();
			log.debug("#### uploading file: "+fileName);
			System.out.println("#### uploading file: "+fileName);
			fileStreamObject = new FileInputStream(file);
			if(fileMap.get(fileName)==null){
				log.debug("#### file: "+fileName+" does not exist!");
				System.out.println("#### file: "+fileName+" does not exist!");
				log.debug("#### uploading new file: "+fileName);
				System.out.println("#### uploading new file: "+fileName);
				fileInfo = childFolder.uploadFile(fileStreamObject,fileName);
				fileStreamObject.close();
				fileId = fileInfo.getID();
				boxFile = new BoxFile(userApiConnection, fileId);
				sharedLink=boxFile.createSharedLink(BoxSharedLink.Access.OPEN, null, permissions);
				jsonObject.put("file_name", fileName);
				jsonObject.put("file_id", fileId);
				jsonObject.put("download_url", sharedLink.getDownloadURL());
				System.out.println("download_url: "+sharedLink.getDownloadURL());
				log.debug("download_url: "+sharedLink.getDownloadURL());
			}else{
				jsonObject=new JSONObject();
				log.debug("#### A file with "+fileName+" already exist!");
				System.out.println("#### A file with "+fileName+" already exist!");
				log.debug("#### uploading new version of: "+fileName);
				System.out.println("#### uploading new version of: "+fileName);
				fileId=fileMap.get(fileName);
				boxFile = new BoxFile(userApiConnection, fileId);
				fileInfo = boxFile.uploadNewVersion(fileStreamObject);
				fileStreamObject.close();
				sharedLink=boxFile.createSharedLink(BoxSharedLink.Access.OPEN, null, permissions);
				jsonObject.put("file_name", fileName);
				jsonObject.put("file_id", fileId);
				jsonObject.put("download_url", sharedLink.getDownloadURL());
				System.out.println("download_url: "+sharedLink.getDownloadURL());
				log.debug("download_url: "+sharedLink.getDownloadURL());
			}
			file.delete();
			jsonArray.add(jsonObject);
		}
		return jsonArray;
	}
	public Map<String,String> getExistingFilesInFolder(BoxFolder childFolder){
		log.debug("#### Entering the getExistingFilesInFolder method of UploadFilesInFolder service ####");
		Map<String,String> fileMap=new HashMap<String,String>();
		BoxFile.Info fileInfo=null;
		String fileName,fileID;
		log.debug("#### files in the current folder: ");
		for (BoxItem.Info itemInfo : childFolder) {
			if (itemInfo instanceof BoxFile.Info) {
				fileInfo = (BoxFile.Info) itemInfo;
				fileID=fileInfo.getID();
				fileName=fileInfo.getName();
				log.debug("#### item: "+fileName+" fileID: "+fileID);
				System.out.println("#### item: "+fileName+" fileID: "+fileID);
				fileMap.put(fileName, fileID);
			}else{
				log.debug("item is not an instance of box fileinfo: ");
			}
		}
		log.debug("#### Exiting the getExistingFilesInFolder method of UploadFilesInFolder service ####");
		return fileMap;
	}
	
}
