package com.box.kony;

import org.apache.log4j.Logger;
import com.box.sdk.BoxConfig;
import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxUser;
import com.box.sdk.CreateUserParams;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;

public class CreateAppUser {
	private static Logger log = Logger.getLogger(CreateAppUser.class);
	private static final int MAX_CACHE_ENTRIES = 100;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String appUserName="Box_User01";
		IAccessTokenCache accessTokenCache = new InMemoryLRUAccessTokenCache(MAX_CACHE_ENTRIES);
		try{
			BoxConfig boxConfig = BoxUtil.getBoxConfig();
			BoxDeveloperEditionAPIConnection userApiConnection = BoxDeveloperEditionAPIConnection.getAppEnterpriseConnection(
	                boxConfig, accessTokenCache);
			CreateUserParams params = new CreateUserParams();
			params.setSpaceAmount(1073741824); //1 GB
			BoxUser.Info user = BoxUser.createAppUser(userApiConnection, appUserName, params);
			System.out.format("User created with name %s and id %s\n\n", appUserName, user.getID());
			
		}catch(Exception e){
			e.printStackTrace();
			log.debug("#### Exception occured in the getFolders method: "+e.getMessage());
		}

	}

}
