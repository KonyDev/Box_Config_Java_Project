package com.box.kony;

import java.io.File;

import org.apache.log4j.Logger;

public class FormItem {
	private static Logger log = Logger.getLogger(FormItem.class);
	private boolean isFile;
	private String paramName;
	private String paramValue;
	private String fileName;
	private String fileExtension;
	private String fileContentType;
	private long fileSize;
	private File file;

	public FormItem(boolean isFile, String paramName, String paramValue, String fileName, String fileExtension,
			String fileContentType, long fileSize, File file) {
		super();
		this.isFile = isFile;
		this.paramName = paramName;
		this.paramValue = paramValue;
		this.fileName = fileName;
		this.fileExtension = fileExtension;
		this.fileContentType = fileContentType;
		this.fileSize = fileSize;
		this.file = file;
		log.debug("#### Entering the constructor of FormItem ####");
		log.debug("#### isFile: "+isFile);
		log.debug("#### paramName: "+paramName);
		log.debug("#### paramValue: "+paramValue);
		log.debug("#### fileName: "+fileName);
		log.debug("#### fileExtension: "+fileExtension);
		log.debug("#### fileContentType: "+fileContentType);
		log.debug("#### fileSize: "+fileSize);
		if(file!=null)
		log.debug("#### file: "+file.toString());
		else
			log.debug("#### file: "+null);	
		log.debug("#### Exiting the constructor of FormItem ####");
	}

	public boolean isFile() {
		return isFile;
	}

	public String getParamName() {
		return paramName;
	}

	public String getParamValue() {
		return paramValue;
	}

	public String getFileName() {
		return fileName;
	}

	public String getFileExtension() {
		return fileExtension;
	}
	
	public String getFileContentType() {
		return fileContentType;
	}
	
	public long getFileSize() {
		return fileSize;
	}

	public File getFile() {
		return file;
	}

}
