package com.box.kony;

import org.apache.log4j.Logger;

import com.box.sdk.BoxConfig;
import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxFolder;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;
import com.box.sdk.JWTEncryptionPreferences;

public class CreateFolderInRootFolder {
	private static Logger log = Logger.getLogger(CreateFolderInRootFolder.class);
	private static final int MAX_CACHE_ENTRIES = 100;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String appUserID = "";
		String parentFolderID = "0";
		String folderName = "folder01";
		try {
			BoxConfig boxConfig = BoxUtil.getBoxConfig();
			log.debug("#### boxConfig :" + boxConfig.toString());
			JWTEncryptionPreferences encryptionPref = boxConfig.getJWTEncryptionPreferences();
			IAccessTokenCache accessTokenCache = new InMemoryLRUAccessTokenCache(MAX_CACHE_ENTRIES);
			BoxDeveloperEditionAPIConnection userApiConnection = BoxDeveloperEditionAPIConnection.getAppUserConnection(
					appUserID, boxConfig.getClientId(), boxConfig.getClientSecret(), encryptionPref, accessTokenCache);
			BoxFolder parentFolder = new BoxFolder(userApiConnection, parentFolderID);
			BoxFolder.Info childFolderInfo = parentFolder.createFolder(folderName);
			log.debug("#### created folderName :" + childFolderInfo.getName());
			log.debug("#### created folder ID :" + childFolderInfo.getID());
			System.out.println("#### created folder ID :" + childFolderInfo.getID());
		} catch (Exception e) {
			e.printStackTrace();
			log.debug("#### Exception occured while creating folder: " + e.getMessage());
		}
	}
}
