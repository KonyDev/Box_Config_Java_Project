package com.box.kony;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import org.apache.log4j.Logger;

import com.box.sdk.BoxConfig;

public class BoxUtil {
	private static Logger log = Logger.getLogger(BoxUtil.class); 
	private static BoxConfig boxConfig = null;
	//static String fileSeparator = System.getProperty("file.separator");

	private BoxUtil() {
	}

	public static BoxConfig getBoxConfig() throws IOException {
		if (boxConfig == null) {
			log.debug("##### creating box config instance ####");
			InputStream is = BoxUtil.class.getClassLoader().getResourceAsStream("config.json");
			Reader reader = new InputStreamReader(is);
			//Reader reader = new FileReader("."+fileSeparator+"resources"+fileSeparator+"config.json");
			boxConfig = BoxConfig.readFrom(reader);
			reader.close();
			log.debug("##### box config object created sucessfully ####");
		}else{
			log.debug("##### box config object already exist ####");
		}
		log.debug("##### returening box config object ####");
		return boxConfig;
	}

}
